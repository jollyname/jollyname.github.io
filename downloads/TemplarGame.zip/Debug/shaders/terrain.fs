#version 330

in vec3 fragWorldPos;
in vec3 fragNormal;

out vec4 finalColor;

uniform float u_maxHeight;

vec3 sampleTerrainColor(float h)
{
	float slope = 1.0 - dot(normalize(fragNormal), vec3(0.0, 1.0, 0.0));

	float rockMask = smoothstep(0.05, 0.25, slope);

	vec3 grass = vec3(0.2, 0.6, 0.2);
	vec3 rock  = vec3(0.5, 0.5, 0.5);

	vec3 color = mix(grass, rock, rockMask);

    return color;
}

void main()
{
    float height01 = clamp(fragWorldPos.y / u_maxHeight, 0.0, 1.0);

    vec3 color = sampleTerrainColor(height01);

    // Simple lighting
    vec3 lightDir = normalize(vec3(0.3, 1.0, 0.2));
    float NdotL = max(dot(normalize(fragNormal), lightDir), 0.2);

    finalColor = vec4(color * NdotL, 1.0);
}
