How to change the Model

Replace assets/models/planet.obj with your own .obj.
(Keep the same name.)

    Model should be centered and reasonably scaled (1 meter radius for best results).


How to change the Texture

Swap assets/textures/grass.png with your own texture.
(Again, keep the same name.)

    Seamless textures work best.